/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

import java.util.List;

/**
 *
 * @author Marimuthu912
 */
public class InstallationDetails {

    /**
     * @return the productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName the productName to set
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * @return the productDesc
     */
    public String getProductDesc() {
        return productDesc;
    }

    /**
     * @param productDesc the productDesc to set
     */
    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    /**
     * @return the productVersion
     */
    public String getProductVersion() {
        return productVersion;
    }

    /**
     * @param productVersion the productVersion to set
     */
    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    /**
     * @return the productZipFileName
     */
    public String getProductZipFileName() {
        return productZipFileName;
    }

    /**
     * @param productZipFileName the productZipFileName to set
     */
    public void setProductZipFileName(String productZipFileName) {
        this.productZipFileName = productZipFileName;
    }

    /**
     * @return the installationDirectory
     */
    public String getInstallationDirectory() {
        return installationDirectory;
    }

    /**
     * @param installationDirectory the installationDirectory to set
     */
    public void setInstallationDirectory(String installationDirectory) {
        this.installationDirectory = installationDirectory;
    }

    /**
     * @return the postInstallationCommands
     */
    public List<PostInstallationCommand> getPostInstallationCommands() {
        return postInstallationCommands;
    }

    /**
     * @param postInstallationCommands the postInstallationCommands to set
     */
    public void setPostInstallationCommands(List<PostInstallationCommand> postInstallationCommands) {
        this.postInstallationCommands = postInstallationCommands;
    }
    private List<PostInstallationCommand> postInstallationCommands;
private String installerTitle;
private String productVersion;
private String productDesc;
private String productName;

private String productZipFileName;
private String installationDirectory;
private String logoIcon;
private List<StepDetails> steps;

    /**
     * @return the installerTitle
     */
    public String getInstallerTitle() {
        return installerTitle;
    }

    /**
     * @param installerTitle the installerTitle to set
     */
    public void setInstallerTitle(String installerTitle) {
        this.installerTitle = installerTitle;
    }

    /**
     * @return the logoIcon
     */
    public String getLogoIcon() {
        return logoIcon;
    }

    /**
     * @param logoIcon the logoIcon to set
     */
    public void setLogoIcon(String logoIcon) {
        this.logoIcon = logoIcon;
    }

    /**
     * @return the steps
     */
    public List<StepDetails> getSteps() {
        return steps;
    }

    /**
     * @param steps the steps to set
     */
    public void setSteps(List<StepDetails> steps) {
        this.steps = steps;
    }


}
