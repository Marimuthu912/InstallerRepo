/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

import java.util.List;

/**
 *
 * @author Marimuthu912
 */
public class StepDetails {

    /**
     * @return the stepTitle
     */
    public String getStepTitle() {
        return stepTitle;
    }

    /**
     * @param stepTitle the stepTitle to set
     */
    public void setStepTitle(String stepTitle) {
        this.stepTitle = stepTitle;
    }

    /**
     * @return the stepType
     */
    public String getStepType() {
        return stepType;
    }

    /**
     * @param stepType the stepType to set
     */
    public void setStepType(String stepType) {
        this.stepType = stepType;
    }

    /**
     * @return the fields
     */
    public List<FieldDetails> getFields() {
        return fields;
    }

    /**
     * @param fields the fields to set
     */
    public void setFields(List<FieldDetails> fields) {
        this.fields = fields;
    }

    private int stepIndex;
    private String stepTitle;
    private String stepDescription;
    private int noOfFields;
    private String postStepProcess;
    private List<FieldDetails> fields;
    private String stepType;

    /**
     * @return the stepIndex
     */
    public int getStepIndex() {
        return stepIndex;
    }

    /**
     * @param stepIndex the stepIndex to set
     */
    public void setStepIndex(int stepIndex) {
        this.stepIndex = stepIndex;
    }


    /**
     * @return the stepDescription
     */
    public String getStepDescription() {
        return stepDescription;
    }

    /**
     * @param stepDescription the stepDescription to set
     */
    public void setStepDescription(String stepDescription) {
        this.stepDescription = stepDescription;
    }

    /**
     * @return the noOfFields
     */
    public int getNoOfFields() {
        return noOfFields;
    }

    /**
     * @param noOfFields the noOfFields to set
     */
    public void setNoOfFields(int noOfFields) {
        this.noOfFields = noOfFields;
    }

    /**
     * @return the postStepProcess
     */
    public String getPostStepProcess() {
        return postStepProcess;
    }

    /**
     * @param postStepProcess the postStepProcess to set
     */
    public void setPostStepProcess(String postStepProcess) {
        this.postStepProcess = postStepProcess;
    }

}
