/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

import com.tcs.ttg.installercreator.business.Validations;
import java.util.List;

/**
 *
 * @author Marimuthu912
 */
public class FieldDetails {

    /**
     * @return the checkBoxValue
     */
    public String getCheckBoxValue() {
        return checkBoxValue;
    }

    /**
     * @param checkBoxValue the checkBoxValue to set
     */
    public void setCheckBoxValue(String checkBoxValue) {
        this.checkBoxValue = checkBoxValue;
    }

    /**
     * @return the isChecked
     */
    public boolean isIsChecked() {
        return isChecked;
    }

    /**
     * @param isChecked the isChecked to set
     */
    public void setIsChecked(boolean isChecked) {
        this.isChecked = isChecked;
    }

    /**
     * @return the values
     */
    public List<FieldValues> getValues() {
        return values;
    }

    /**
     * @param values the values to set
     */
    public void setValues(List<FieldValues> values) {
        this.values = values;
    }

    /**
     * @return the fieldName
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * @param fieldName the fieldName to set
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }
    private String fieldLabel;
    private String fieldType;
    private String fieldDataType;
    private String fieldName;
    private String checkBoxValue;
    private Validations validations;
    private boolean isChecked;
    private List<FieldValues> values;
    /**
     * @return the fieldLabel
     */
    public String getFieldLabel() {
        return fieldLabel;
    }

    /**
     * @param fieldLabel the fieldLabel to set
     */
    public void setFieldLabel(String fieldLabel) {
        this.fieldLabel = fieldLabel;
    }

    /**
     * @return the fieldType
     */
    public String getFieldType() {
        return fieldType;
    }

    /**
     * @param fieldType the fieldType to set
     */
    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    /**
     * @return the fieldDataType
     */
    public String getFieldDataType() {
        return fieldDataType;
    }

    /**
     * @param fieldDataType the fieldDataType to set
     */
    public void setFieldDataType(String fieldDataType) {
        this.fieldDataType = fieldDataType;
    }

    /**
     * @return the validations
     */
    public Validations getValidations() {
        return validations;
    }

    /**
     * @param validations the validations to set
     */
    public void setValidations(Validations validations) {
        this.validations = validations;
    }
}
