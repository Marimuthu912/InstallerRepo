/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.business;

import java.util.HashMap;
import java.util.Map;
import javax.swing.JPanel;

/**
 *
 * @author Marimuthu912
 */
public class GlobalVars {
    public static int currentStep=0;
    public static Map<Integer,JPanel> mapOfStepIndexAndWizardPanel = new HashMap<>();
    public static Map<String,String> mapOfFieldNameAndValue = new HashMap<>();
    
}
