/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.business;

import com.tcs.ttg.installercreator.utils.WizardUtils;
import com.tcs.ttg.installercreator.model.InstallationDetails;
import com.tcs.ttg.installercreator.model.StepDetails;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.awt.Component;
// www . j  a va2s.  c om
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Marimuthu912
 */
public class InstallerCreator {

    public static void main(String[] args) throws IOException {

        InstallerCreator installerCreator = new InstallerCreator();
        InstallationDetails installationDetails = installerCreator.loadInstallationDetailsJSON();

        Map<Integer, StepDetails> mapOfStepIndexAndStepDetails = new HashMap<>();
        int stepIndex=0;
        for (StepDetails stepDetails : installationDetails.getSteps()) {
            stepDetails.setStepIndex(stepIndex++);
            mapOfStepIndexAndStepDetails.put(stepDetails.getStepIndex(), stepDetails);
        }
        JFrame viewPort = new JFrame(installationDetails.getInstallerTitle());
        //viewPort.setLayout(new BorderLayout());
        viewPort.setLayout(null);
        Container c = viewPort.getContentPane();
        JPanel stepsPanel = new JPanel();
        List<String> stepTitles = installationDetails.getSteps().stream().map(stepDetails -> {
            return stepDetails.getStepTitle();
        }).collect(Collectors.toList());
//        String week[] = {"Introduction", "Installation Location", "License File",
//            "Java Home Path", "Email Id Of Admin User", "Installing", "Installtion Complete"};        
        stepsPanel.setBounds(0, 0, 250, 500);
        stepsPanel.setBackground(Color.lightGray);
        //create list 

        JList b = new JList(stepTitles.toArray());

        b.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {

            }
        });
        b.setBounds(5, 30, 230, 400);
        b.setCellRenderer(getRenderer());
        stepsPanel.add(b);
        stepsPanel.setLayout(null);
        c.add(stepsPanel);

        ImageIcon frmaeIcon = new ImageIcon("config//icons//"+installationDetails.getLogoIcon());
        viewPort.setIconImage(frmaeIcon.getImage());
        viewPort.setSize(750, 500);

        viewPort.setLocationRelativeTo(null);
        WizardUtils.addStepPanelToViewPort(viewPort, 0, mapOfStepIndexAndStepDetails, installationDetails);

        b.setSelectedIndex(0);
        viewPort.setVisible(true);
        viewPort.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public InstallationDetails loadInstallationDetailsJSON() throws IOException {
        // ClassLoader classLoader = getClass().getClassLoader();
        ObjectMapper mapper = new ObjectMapper();
        //File jsonInstallationFile = new File(classLoader.getResource("Installation-Data.json").getFile());
        File jsonInstallationFile = new File("config//Installation-Data.json");
        return mapper.readValue(jsonInstallationFile, InstallationDetails.class);
    }

    private static ListCellRenderer<? super String> getRenderer() {
        return new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList list,
                    Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel listCellRendererComponent = (JLabel) super
                        .getListCellRendererComponent(list, value, index, isSelected,
                                cellHasFocus);
                listCellRendererComponent.setBorder(BorderFactory.createMatteBorder(7,
                        10, 1, 0, Color.WHITE));
                if (!isSelected) {
          //          System.out.println("index is "+index);
                    ImageIcon frmaeIcon = new ImageIcon("config//icons//list-item.png");
                    listCellRendererComponent.setIcon(frmaeIcon);
                    
                    //listCellRendererComponent.setForeground(Color.GRAY);
                } else {
                    ImageIcon frmaeIcon = new ImageIcon("config//icons//right-arr.png");
                    listCellRendererComponent.setIcon(frmaeIcon);
                    listCellRendererComponent.setBackground(Color.WHITE);
                }
                if(index<GlobalVars.currentStep){
                    ImageIcon frmaeIcon = new ImageIcon("config//icons//tick.png");
                    listCellRendererComponent.setIcon(frmaeIcon);
                    listCellRendererComponent.setForeground(Color.BLACK);
                }
                if(index>GlobalVars.currentStep){
                    listCellRendererComponent.setForeground(Color.LIGHT_GRAY);
                }
                if(index==GlobalVars.currentStep){
                    //listCellRendererComponent.setForeground(Color.BLUE);
                }
                
                return listCellRendererComponent;
            }
        };
    }

    public static void addStepPanelToViewPort(JFrame viewPort, int stepIndex, Map<Integer, StepDetails> mapOfStepIndexAndStepDetails, InstallationDetails installationDetails) {

        if (viewPort.getContentPane().getComponents().length >= 2) {
            viewPort.getContentPane().remove(1);
        }

        if (GlobalVars.mapOfStepIndexAndWizardPanel.containsKey(stepIndex)) {
            viewPort.add(GlobalVars.mapOfStepIndexAndWizardPanel.get(stepIndex));
        } else {
            WizardPanel wizardPanel = new WizardPanel();
            wizardPanel.setViewPort(viewPort);
            wizardPanel.setInstallationDetails(installationDetails);
            wizardPanel.setCurrentStepIndex(stepIndex);
            wizardPanel.setMapOfStepIndexAndStepDetails(mapOfStepIndexAndStepDetails);
            JPanel nextStepPanel = wizardPanel.createWizardPanel();
            viewPort.add(nextStepPanel);
            GlobalVars.mapOfStepIndexAndWizardPanel.put(stepIndex, nextStepPanel);
        }
        viewPort.revalidate();
        viewPort.repaint();
    }
}
