/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

/**
 *
 * @author Marimuthu912
 */
public class FindAndReplaceModel {
   private String findText;
   private String replaceText;

    /**
     * @return the findText
     */
    public String getFindText() {
        return findText;
    }

    /**
     * @param findText the findText to set
     */
    public void setFindText(String findText) {
        this.findText = findText;
    }

    /**
     * @return the replaceText
     */
    public String getReplaceText() {
        return replaceText;
    }

    /**
     * @param replaceText the replaceText to set
     */
    public void setReplaceText(String replaceText) {
        this.replaceText = replaceText;
    }

    
}
