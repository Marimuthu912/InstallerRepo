/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.business;

import com.tcs.ttg.installercreator.model.PostInstallationCommand;
import com.tcs.ttg.installercreator.model.CopyFileCommand;
import com.tcs.ttg.installercreator.model.InstallationDetails;
import com.tcs.ttg.installercreator.model.FindAndReplaceModel;
import com.tcs.ttg.installercreator.model.ReplaceFileContentsCommand;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.swing.SwingWorker;

/**
 *
 * @author Marimuthu912
 */
public class PostInstaller extends SwingWorker<Void, Void> {

    /**
     * @return the installationDetails
     */
    public InstallationDetails getInstallationDetails() {
        return installationDetails;
    }

    /**
     * @param installationDetails the installationDetails to set
     */
    public void setInstallationDetails(InstallationDetails installationDetails) {
        this.installationDetails = installationDetails;
    }

    /**
     * @return the scriptsToBeExecuted
     */
    public String getScriptsToBeExecuted() {
        return scriptsToBeExecuted;
    }

    /**
     * @param scriptsToBeExecuted the scriptsToBeExecuted to set
     */
    public void setScriptsToBeExecuted(String scriptsToBeExecuted) {
        this.scriptsToBeExecuted = scriptsToBeExecuted;
    }

    private String scriptsToBeExecuted;
    private String installationFolderPath;
    private InstallationDetails installationDetails;

    private void executeScripts() {
        List<PostInstallationCommand> postInstallationCommands = getInstallationDetails().getPostInstallationCommands();

        for (PostInstallationCommand postInstallationCommand : postInstallationCommands) {
            switch (postInstallationCommand.getCommandName()) {
                case "Copy-File":
                    CopyFileCommand p=(CopyFileCommand)postInstallationCommand;
                {
                    try {
                        File sourceFile=new File(GlobalVars.mapOfFieldNameAndValue.get(p.getSourcePath()));
                        Files.copy(sourceFile.toPath(), new File(installationDetails.getInstallationDirectory()
                                +File.separator+p.getDestinationPath()+File.separator+sourceFile.getName()).toPath(),StandardCopyOption.REPLACE_EXISTING);
                    } catch (IOException ex) {
                        Logger.getLogger(PostInstaller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                    break;

                case "ExecuteScriptCommand":
                    break;
                case "Replace-File-Contents":
                    ReplaceFileContentsCommand replaceFileContentsCommand=(ReplaceFileContentsCommand)postInstallationCommand;
                {
                    try {
                        String content = new String(Files.readAllBytes(Paths.get(installationDetails.getInstallationDirectory()
                                +File.separator+replaceFileContentsCommand.getFilePath())));
                        List<FindAndReplaceModel> findAndReplaceModels=replaceFileContentsCommand.getReplaceInformation();
                        for(FindAndReplaceModel findAndReplaceModel:findAndReplaceModels){
                            content=content.replaceAll(findAndReplaceModel.getFindText(), GlobalVars.mapOfFieldNameAndValue.get(findAndReplaceModel.getReplaceText()));
                        }
                        Files.write(Paths.get(installationDetails.getInstallationDirectory()
                                +File.separator+replaceFileContentsCommand.getFilePath()), content.getBytes(), StandardOpenOption.WRITE);
                        System.out.println(content);
                    } catch (IOException ex) {
                        Logger.getLogger(PostInstaller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                    
                    break;

                default:
                    break;

            }

        }
//        ProcessBuilder processBuilder = new ProcessBuilder();
//        processBuilder.command("cmd.exe", "/c","cd "+installationFolderPath+"&"+getScriptsToBeExecuted());
//        try {
//            processBuilder.start();
//        } catch (IOException ex) {
//            Logger.getLogger(ExecuteScriptsTask.class.getName()).log(Level.SEVERE, null, ex);
//        }        

    }

    /*
     * Main task. Executed in background thread.
     */
    @Override
    public Void doInBackground() {
        executeScripts();
        return null;
    }

    /**
     * @return the installationFolderPath
     */
    public String getInstallationFolderPath() {
        return installationFolderPath;
    }

    /**
     * @param installationFolderPath the installationFolderPath to set
     */
    public void setInstallationFolderPath(String installationFolderPath) {
        this.installationFolderPath = installationFolderPath;
    }

}
