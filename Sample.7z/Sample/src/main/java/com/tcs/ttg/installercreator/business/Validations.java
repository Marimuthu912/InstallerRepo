/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.business;

/**
 *
 * @author Marimuthu912
 */
public class Validations {
    private int minChars;
    private int maxChars;

    /**
     * @return the minChars
     */
    public int getMinChars() {
        return minChars;
    }

    /**
     * @param minChars the minChars to set
     */
    public void setMinChars(int minChars) {
        this.minChars = minChars;
    }

    /**
     * @return the maxChars
     */
    public int getMaxChars() {
        return maxChars;
    }

    /**
     * @param maxChars the maxChars to set
     */
    public void setMaxChars(int maxChars) {
        this.maxChars = maxChars;
    }
    
}
