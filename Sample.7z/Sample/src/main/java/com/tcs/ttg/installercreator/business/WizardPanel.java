/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.business;

import com.tcs.ttg.installercreator.utils.WizardUtils;
import com.tcs.ttg.installercreator.model.InstallationDetails;
import com.tcs.ttg.installercreator.model.FieldValues;
import com.tcs.ttg.installercreator.model.FieldDetails;
import com.tcs.ttg.installercreator.model.StepDetails;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Marimuthu912
 */
public class WizardPanel {

    /**
     * @return the installationDetails
     */
    public InstallationDetails getInstallationDetails() {
        return installationDetails;
    }

    /**
     * @param installationDetails the installationDetails to set
     */
    public void setInstallationDetails(InstallationDetails installationDetails) {
        this.installationDetails = installationDetails;
    }

    /**
     * @return the mapOfStepIndexAndStepDetails
     */
    public Map<Integer, StepDetails> getMapOfStepIndexAndStepDetails() {
        return mapOfStepIndexAndStepDetails;
    }

    /**
     * @param mapOfStepIndexAndStepDetails the mapOfStepIndexAndStepDetails to
     * set
     */
    public void setMapOfStepIndexAndStepDetails(Map<Integer, StepDetails> mapOfStepIndexAndStepDetails) {
        this.mapOfStepIndexAndStepDetails = mapOfStepIndexAndStepDetails;
    }

    /**
     * @return the currentStepIndex
     */
    public int getCurrentStepIndex() {
        return currentStepIndex;
    }

    /**
     * @param currentStepIndex the currentStepIndex to set
     */
    public void setCurrentStepIndex(int currentStepIndex) {
        this.currentStepIndex = currentStepIndex;
    }
    private InstallationDetails installationDetails;
    JPanel workignAreaPanel = null;
    private int currentStepIndex;
    private JFrame viewPort;
    private Map<Integer, StepDetails> mapOfStepIndexAndStepDetails;

    public JPanel createWizardPanel() {

        JPanel workignAreaPanel = new JPanel();
        StepDetails stepDetails = mapOfStepIndexAndStepDetails.get(currentStepIndex);
        List<FieldDetails> fields = stepDetails.getFields();
        JLabel stepTitle = new JLabel(stepDetails.getStepTitle());
        workignAreaPanel.setLayout(null);
        workignAreaPanel.add(stepTitle);
        stepTitle.setBounds(5, 3, 400, 20);
        JTextArea stepDescription = null;
        if (stepDetails.getStepType() != null
                && stepDetails.getStepType().equals("InstallationCompletion")) {
            stepDescription = new JTextArea("Product has been installed in the location - " + installationDetails.getInstallationDirectory());
        } else {
            stepDescription = new JTextArea(stepDetails.getStepDescription());
        }
        stepDescription.setBounds(5, 31, 450, 130);
        stepDescription.setEditable(false);
        workignAreaPanel.add(stepDescription);

        if (stepDetails.getStepType() != null
                && stepDetails.getStepType().equals("InstallationInProgress")) {
            JLabel progressMessage = new JLabel("Extracting Artifacts....");
            JProgressBar jProgressBar = new JProgressBar(0, 100);
            progressMessage.setBounds(5, 280, 300, 20);
            jProgressBar.setBounds(5, 320, 450, 30);
            workignAreaPanel.add(progressMessage);
            workignAreaPanel.add(jProgressBar);
            final ExtractArtifacts extractTask = new ExtractArtifacts();
            extractTask.setArtifactsZipFilePath("Artifact" + File.separator + installationDetails.getProductZipFileName());
            extractTask.setInstallationFolderPath(installationDetails.getInstallationDirectory());
            extractTask.addPropertyChangeListener(new PropertyChangeListener() {
                @Override
                public void propertyChange(PropertyChangeEvent pcEvt) {
                    if ("progress".equals(pcEvt.getPropertyName())) {
                        jProgressBar.setValue((Integer) pcEvt.getNewValue());
                    } else if (pcEvt.getNewValue() == SwingWorker.StateValue.DONE) {
                        try {
                            extractTask.get();
                            progressMessage.setText("Executing installation scripts...");
                            //jProgressBar.setValue(100);
                            final PostInstaller executeScriptsTask = new PostInstaller();
                            executeScriptsTask.setInstallationFolderPath(installationDetails.getInstallationDirectory());
                            executeScriptsTask.setInstallationDetails(installationDetails);
                            executeScriptsTask.addPropertyChangeListener(new PropertyChangeListener() {
                                @Override
                                public void propertyChange(PropertyChangeEvent pcEvt) {
                                    if ("progress".equals(pcEvt.getPropertyName())) {
                                        jProgressBar.setValue((Integer) pcEvt.getNewValue());
                                    } else if (pcEvt.getNewValue() == SwingWorker.StateValue.DONE) {
                                        try {
                                            executeScriptsTask.get();
                                            progressMessage.setText("Finished.");
                                            WizardUtils.addStepPanelToViewPort(viewPort, getCurrentStepIndex() + 1, mapOfStepIndexAndStepDetails, installationDetails);
                                            JPanel stepsPanel = (JPanel) viewPort.getContentPane().getComponent(0);
                                            for (Component comp : stepsPanel.getComponents()) {
                                                if (comp instanceof JList) {
                                                    JList stepList = (JList) comp;
                                                    stepList.setSelectedIndex(getCurrentStepIndex() + 1);
                                                }

                                            }
                                            //jProgressBar.setValue(100);
                                        } catch (InterruptedException | ExecutionException e) {
                                            // handle any errors here
                                            e.printStackTrace();
                                        }
                                    }

                                }
                            });
                            executeScriptsTask.execute();
                        } catch (InterruptedException | ExecutionException e) {
                            // handle any errors here
                            e.printStackTrace();
                        }
                    }

                }
            });
            extractTask.execute();

        }
        if (fields != null) {
            String fieldLabel = null, fieldType = null;
            int currentYPosition = 180;
            for (FieldDetails field : fields) {
                fieldLabel = field.getFieldLabel();
                fieldType = field.getFieldType();
                //   GlobalVars.mapOfFieldNameAndValue.put(field.getFieldName(), "");
                switch (fieldType) {
                    case "TextArea":
                        JLabel textAreaLabel = new JLabel(fieldLabel);
                        textAreaLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(textAreaLabel);
                        JTextArea textAreaField = new JTextArea();
                        textAreaField.setBounds(160, currentYPosition, 300, 50);
                        textAreaField.setToolTipText(field.getFieldName());
                        textAreaField.getDocument().addDocumentListener(new DocumentListener() {
                            public void changedUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void removeUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void insertUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void updateFieldValue() {
                                GlobalVars.mapOfFieldNameAndValue.put("$" + field.getFieldName(), textAreaField.getText());
                            }
                        });
                        workignAreaPanel.add(textAreaField);
                        currentYPosition = currentYPosition + 60;
                        break;
                    case "CheckBox":
                        JLabel checkBoxfieldLabel = new JLabel(fieldLabel);
                        checkBoxfieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(checkBoxfieldLabel);
                        JCheckBox checkBoxField = new JCheckBox(field.getCheckBoxValue());
                        checkBoxField.setBackground(Color.lightGray);
                        if (field.isIsChecked()) {
                            checkBoxField.setSelected(true);
                        }
                        checkBoxField.setToolTipText(field.getFieldName());
                        checkBoxField.setBounds(160, currentYPosition, 300, 20);
                        workignAreaPanel.add(checkBoxField);
                        currentYPosition = currentYPosition + 30;
                        break;
                    case "ComboBox":
                        List<String> comboValues = new ArrayList<>();
                        for (FieldValues fieldValue : field.getValues()) {
                            comboValues.add(fieldValue.getDisplayName());
                        }
                        JLabel comboBoxfieldLabel = new JLabel(fieldLabel);
                        comboBoxfieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(comboBoxfieldLabel);
                        JComboBox comboBoxField = new JComboBox(comboValues.toArray());
                        comboBoxField.setSelectedIndex(1);
                        comboBoxField.setBounds(160, currentYPosition, 300, 20);
                        workignAreaPanel.add(comboBoxField);
                        currentYPosition = currentYPosition + 30;
                        break;
                    case "RadioButton":
                        JLabel radioButtonFieldLabel = new JLabel(fieldLabel);
                        radioButtonFieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(radioButtonFieldLabel);

                        field.getValues();
                        ButtonGroup bg = new ButtonGroup();

                        for (FieldValues fieldValue : field.getValues()) {
                            JRadioButton radioButtonField = new JRadioButton(fieldValue.getDisplayName());
                            radioButtonField.setBackground(Color.lightGray);
                            if (fieldValue.isIsSelected()) {
                                radioButtonField.setSelected(true);
                            }
                            radioButtonField.setBounds(160, currentYPosition, 300, 20);

                            bg.add(radioButtonField);
                            workignAreaPanel.add(radioButtonField);
                            currentYPosition = currentYPosition + 30;
                        }

                        break;
                    case "TextBox":
                        JLabel textfieldLabel = new JLabel(fieldLabel);
                        textfieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(textfieldLabel);
                        JTextField textField = new JTextField();
                        textField.getDocument().addDocumentListener(new DocumentListener() {
                            public void changedUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void removeUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void insertUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void updateFieldValue() {
//                                if (Integer.parseInt(textField.getText()) > 0) {
                                GlobalVars.mapOfFieldNameAndValue.put("$" + field.getFieldName(), textField.getText());
                                //                              }
                            }
                        });
                        textField.setToolTipText(field.getFieldName());
                        textField.setBounds(160, currentYPosition, 300, 20);
                        workignAreaPanel.add(textField);
                        currentYPosition = currentYPosition + 30;
                        break;
                    case "Password":
                        JLabel passwordfieldLabel = new JLabel(fieldLabel);
                        passwordfieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(passwordfieldLabel);
                        JPasswordField passwordField = new JPasswordField();
                        passwordField.setBounds(160, currentYPosition, 300, 20);
                        passwordField.setToolTipText(field.getFieldName());
                        passwordField.getDocument().addDocumentListener(new DocumentListener() {
                            public void changedUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void removeUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void insertUpdate(DocumentEvent e) {
                                updateFieldValue();
                            }

                            public void updateFieldValue() {
                                GlobalVars.mapOfFieldNameAndValue.put("$" + field.getFieldName(), passwordField.getText());
                            }
                        });
                        workignAreaPanel.add(passwordField);
                        currentYPosition = currentYPosition + 30;
                        break;
                    case "Folder":
                        JLabel folderFieldLabel = new JLabel(fieldLabel);
                        folderFieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(folderFieldLabel);
                        JTextField folderField = new JTextField();
                        folderField.setBounds(160, currentYPosition, 230, 20);
                        folderField.setEditable(false);
                        workignAreaPanel.add(folderField);
                        JButton browseFolderButton = new JButton("Browse");
                        browseFolderButton.setBounds(400, currentYPosition, 50, 20);
                        browseFolderButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                // display/center the jdialog when the button is pressed
                                JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                                j.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                                int r = j.showOpenDialog(null);

                                if (r == JFileChooser.APPROVE_OPTION) {
                                    folderField.setText(j.getSelectedFile().getAbsolutePath());
                                    GlobalVars.mapOfFieldNameAndValue.put("$" + field.getFieldName(), folderField.getText());
                                    if (field.getFieldName().equals("installationDirectory")) {
                                        installationDetails.setInstallationDirectory(folderField.getText());

                                    }
                                } // if the user cancelled the operation 
                                else {
                                    folderField.setText("Choose file location");
                                }

                            }
                        });
                        workignAreaPanel.add(browseFolderButton);

                        currentYPosition = currentYPosition + 30;
                        break;
                    case "File":
                        JLabel filefieldLabel = new JLabel(fieldLabel);
                        filefieldLabel.setBounds(5, currentYPosition, 150, 20);
                        workignAreaPanel.add(filefieldLabel);
                        JTextField fileField = new JTextField();
                        fileField.setBounds(160, currentYPosition, 230, 20);
                        fileField.setEditable(false);
                        workignAreaPanel.add(fileField);
                        JButton browseFileButton = new JButton("Browse");
                        browseFileButton.setBounds(400, currentYPosition, 50, 20);
                        browseFileButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                // display/center the jdialog when the button is pressed
                                JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                                //j.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                                int r = j.showOpenDialog(null);

                                if (r == JFileChooser.APPROVE_OPTION) {
                                    fileField.setText(j.getSelectedFile().getAbsolutePath());
                                    GlobalVars.mapOfFieldNameAndValue.put("$" + field.getFieldName(), fileField.getText());
//                                    Path sourcePath = j.getSelectedFile().toPath();
//                                    Path destinationPath = new File("D://icons//" + j.getSelectedFile().getName()).toPath();
//                                    try {
//                                        Files.copy(sourcePath, destinationPath);
//                                    } catch (IOException e1) {
//                                        e1.printStackTrace();
//                                    }
                                } // if the user cancelled the operation 
                                else {
                                    fileField.setText("Choose file location");
                                }

                            }
                        });
                        workignAreaPanel.add(browseFileButton);

                        currentYPosition = currentYPosition + 30;
                        break;
                    default:
                        break;
                }

            };

        }

//        
        JPanel bottomButtonsPanel = new JPanel();
        JButton nextButton = new JButton("Next");

        JButton prevButton = new JButton("Previuos");
        if (stepDetails.getStepIndex() == 0) {
            prevButton.setEnabled(false);
        } else {
            prevButton.setEnabled(true);
        }

        JButton cancelButton = new JButton("Cancel");
        bottomButtonsPanel.add(prevButton);
        bottomButtonsPanel.add(nextButton);
        if (stepDetails.getStepType() != null
                && stepDetails.getStepType().equals("PreInstallationSummary")) {
            nextButton.setEnabled(false);
            JButton installButton = new JButton("Install");
            installButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //  viewPort.getContentPane().remove(1);
                    WizardUtils.addStepPanelToViewPort(viewPort, getCurrentStepIndex() + 1, mapOfStepIndexAndStepDetails, installationDetails);
                    JPanel stepsPanel = (JPanel) viewPort.getContentPane().getComponent(0);
                    GlobalVars.currentStep = getCurrentStepIndex() + 1;
                    Set<Entry<Integer, JPanel>> entryOfPanels = GlobalVars.mapOfStepIndexAndWizardPanel.entrySet();
                    for (Entry<Integer, JPanel> panelEntry : entryOfPanels) {
                        JPanel panel = panelEntry.getValue();
                        String fieldValue = "";
                        for (Component comp : panel.getComponents()) {
                            if (comp instanceof JTextField) {
                                fieldValue = ((JTextField) comp).getText();
                            }

                            if (comp instanceof JPasswordField) {
                                fieldValue = ((JPasswordField) comp).getText();
                            }
                            if (comp instanceof JTextArea) {
                                fieldValue = ((JTextArea) comp).getText();
                            }

                        }
                    }
                    for (Component comp : stepsPanel.getComponents()) {
                        if (comp instanceof JList) {
                            JList stepList = (JList) comp;
                            stepList.setSelectedIndex(getCurrentStepIndex() + 1);
                        }

                    }

                }
            });
            bottomButtonsPanel.add(installButton);
        } //        else  if (stepDetails.getStepType()!=null &&
        //            stepDetails.getStepType().equals("InstallationCompletion")) {
        //             nextButton.setVisible(false);
        //            JButton doneInstallButton = new JButton("Done");
        //            bottomButtonsPanel.add(doneInstallButton);
        //        }
        else {
            // nextButton.setVisible(true);
            if (stepDetails.getStepType() != null
                    && stepDetails.getStepType().equals("InstallationCompletion")) {
                JPanel stepsPanel = (JPanel) viewPort.getContentPane().getComponent(0);
                for (Component comp : stepsPanel.getComponents()) {
                    if (comp instanceof JList) {
                        JList stepList = (JList) comp;
                        stepList.setEnabled(false);
                    }

                }
                nextButton.setVisible(false);
                prevButton.setVisible(false);
                cancelButton.setVisible(false);
//                JLabel installationCompletedMessage = new JLabel("Product has been installed in the location - "+installationDetails.getInstallationDirectory());
//                workignAreaPanel.add(viewPort)
                JButton doneInstallButton = new JButton("Done");
                doneInstallButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // display/center the jdialog when the button is pressed

                        getViewPort().dispose();
                    }
                });
                bottomButtonsPanel.add(doneInstallButton);
            } else {
                nextButton.setVisible(true);
                prevButton.setVisible(true);
                cancelButton.setVisible(true);
                nextButton.setEnabled(true);
            }
        }
        bottomButtonsPanel.add(cancelButton);

        // bottomButtonsPanel.setBackground(Color.getHSBColor(195, 100, 100));
        bottomButtonsPanel.setBounds(0, 420, 500, 50);
        workignAreaPanel.setBackground(Color.LIGHT_GRAY);
//  if (stepDetails.getStepType()!=null &&
//            stepDetails.getStepType().equals("InstallationCompletion")) {
//            nextButton.setVisible(false);
//            JButton installDoneButton = new JButton("Done");
//            bottomButtonsPanel.add(installDoneButton);
//        } else {
//            nextButton.setEnabled(true);
//        }
        // workignAreaPanel.add(installtionPath);
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isStepValid(mapOfStepIndexAndStepDetails.get(currentStepIndex), viewPort)) {
                    WizardUtils.addStepPanelToViewPort(viewPort, getCurrentStepIndex() + 1, mapOfStepIndexAndStepDetails, installationDetails);
                    GlobalVars.currentStep = getCurrentStepIndex() + 1;
                    JPanel stepsPanel = (JPanel) viewPort.getContentPane().getComponent(0);
                    for (Component comp : stepsPanel.getComponents()) {
                        if (comp instanceof JList) {
                            JList stepList = (JList) comp;
                            stepList.setSelectedIndex(getCurrentStepIndex() + 1);
                            //System.out.println("List found");
                        }

                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please fix the errors in the step to proceed.");
                }

            }
        });
        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WizardUtils.addStepPanelToViewPort(viewPort, getCurrentStepIndex() - 1, mapOfStepIndexAndStepDetails, installationDetails);
                GlobalVars.currentStep = getCurrentStepIndex() - 1;
                //  viewPort.getContentPane().remove(1);
                JPanel stepsPanel = (JPanel) viewPort.getContentPane().getComponent(0);
                for (Component comp : stepsPanel.getComponents()) {
                    if (comp instanceof JList) {
                        JList stepList = (JList) comp;
                        stepList.setSelectedIndex(getCurrentStepIndex() - 1);
                        // System.out.println("List found");
                    }

                }

            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // display/center the jdialog when the button is pressed
                int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to cancel the installation?");
                // 0=yes, 1=no, 2=cancel
                if (input == 0) {
                    getViewPort().dispose();
                }

            }
        });
        // workignAreaPanel.add(installtionPathTextField);
        if (stepDetails.getStepType() != null
                && stepDetails.getStepType().equals("InstallationInProgress")) {
            nextButton.setVisible(false);
            prevButton.setVisible(false);
            cancelButton.setVisible(true);

        }
        workignAreaPanel.add(bottomButtonsPanel);
        workignAreaPanel.setBounds(260, 0, 500, 500);

        return workignAreaPanel;
    }

    /**
     * @return the viewPort
     */
    public JFrame getViewPort() {
        return viewPort;
    }

    /**
     * @param viewPort the viewPort to set
     */
    public void setViewPort(JFrame viewPort) {
        this.viewPort = viewPort;
    }

    static boolean isStepValid(StepDetails stepDetails, JFrame viewPort) {
        JPanel stepsPanel = (JPanel) viewPort.getContentPane().getComponent(1);
        boolean isStepValid = true;
        List<FieldDetails> fields = stepDetails.getFields();

        for (Component comp : stepsPanel.getComponents()) {
            if (comp instanceof JTextField) {
                if (((JTextField) comp).getText().isEmpty()) {
                    isStepValid = false;
                    break;
                } else {
                    JTextField textField = (JTextField) comp;
                    for (FieldDetails field : fields) {
                        if (field.getFieldName().equals(textField.getToolTipText())) {                            
                            if (field.getFieldDataType() != null && field.getFieldDataType().equals("Numeric")) {
                                if (!textField.getText().matches("^([0-9]{4})$")) {
                                    JOptionPane.showMessageDialog(null,"Field "+textField.getToolTipText()+" must contain only numbers.");
                                    return false;
                                }
                            }

                        }
                    }
                }

            }
            if (comp instanceof JPasswordField) {
                if (((JPasswordField) comp).getText().isEmpty()) {
                    isStepValid = false;
                    break;
                }
            }
            if (comp instanceof JTextArea) {
                if (((JTextArea) comp).getText().isEmpty()) {
                    isStepValid = false;
                    break;
                }
            }
        }
        return isStepValid;
    }
}
