/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

import java.util.List;

/**
 *
 * @author Marimuthu912
 */
public class ReplaceFileContentsCommand extends PostInstallationCommand{

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

       private String filePath;
       
    /**
     * @return the replaceInformation
     */
    public List<FindAndReplaceModel> getReplaceInformation() {
        return replaceInformation;
    }

    /**
     * @param replaceInformation the replaceInformation to set
     */
    public void setReplaceInformation(List<FindAndReplaceModel> replaceInformation) {
        this.replaceInformation = replaceInformation;
    }
    private List<FindAndReplaceModel> replaceInformation;
}
