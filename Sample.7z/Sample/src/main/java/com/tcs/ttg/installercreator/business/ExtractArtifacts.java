/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.business;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.swing.SwingWorker;

/**
 *
 * @author Marimuthu912
 */
public class ExtractArtifacts extends SwingWorker<Void, Void> {

    private String installationFolderPath;
    private String artifactsZipFilePath;

    private void extractArtifacts() {
        try {
            unzip(getArtifactsZipFilePath(), getInstallationFolderPath());
            System.out.println("Completed unzipping");
        } catch (IOException ex) {
            Logger.getLogger(InstalltionInitiator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void unzip(String zipFilePath, String destDirectory) throws IOException {

        try {
            /*
 * STEP 1 : Create directory with the name of the zip file
 * 
 * For e.g. if we are going to extract c:/demo.zip create c:/demo 
 * directory where we can extract all the zip entries
 * 
             */
            File fSourceZip = new File(zipFilePath);
            float totalSize = fSourceZip.length();

            /*
 * STEP 2 : Extract entries while creating required
 * sub-directories
 * 
             */
            ZipFile zipFile = new ZipFile(fSourceZip);
            Enumeration e = zipFile.entries();
            int fileIndex = 0;
            while (e.hasMoreElements()) {
                ZipEntry entry = (ZipEntry) e.nextElement();
                File destinationFilePath = new File(destDirectory, entry.getName());

                //create directories if required.
                destinationFilePath.getParentFile().mkdirs();

                //if the entry is directory, leave it. Otherwise extract it.
                if (entry.isDirectory()) {
                    continue;
                } else {
                    BufferedInputStream bis = new BufferedInputStream(zipFile
                            .getInputStream(entry));

                    int b;
                    byte buffer[] = new byte[1024];

                    /*
 * read the current entry from the zip file, extract it
 * and write the extracted file.
                     */
                    FileOutputStream fos = new FileOutputStream(destinationFilePath);
                    BufferedOutputStream bos = new BufferedOutputStream(fos,
                            1024);
                    int index = 0;
                    while ((b = bis.read(buffer, 0, 1024)) != -1) {
                        bos.write(buffer, 0, b);                        
                        ++fileIndex;
                        if (fileIndex == 100) {
                            fileIndex = 0;
                        }
                        if (fileIndex % 20 == 0) {
                            setProgress(fileIndex);
                        }

                    }

                    //flush the output stream and close it.
                    bos.flush();
                    bos.close();

                    //close the input stream.
                    bis.close();
                }
            }
        } catch (IOException ioe) {
            System.out.println("IOError :" + ioe);
        }
    }

    /*
     * Main task. Executed in background thread.
     */
    @Override
    public Void doInBackground() {
        extractArtifacts();
        return null;
    }

    /**
     * @return the installationFolderPath
     */
    public String getInstallationFolderPath() {
        return installationFolderPath;
    }

    /**
     * @param installationFolderPath the installationFolderPath to set
     */
    public void setInstallationFolderPath(String installationFolderPath) {
        this.installationFolderPath = installationFolderPath;
    }

    /**
     * @return the artifactsZipFilePath
     */
    public String getArtifactsZipFilePath() {
        return artifactsZipFilePath;
    }

    /**
     * @param artifactsZipFilePath the artifactsZipFilePath to set
     */
    public void setArtifactsZipFilePath(String artifactsZipFilePath) {
        this.artifactsZipFilePath = artifactsZipFilePath;
    }

}
