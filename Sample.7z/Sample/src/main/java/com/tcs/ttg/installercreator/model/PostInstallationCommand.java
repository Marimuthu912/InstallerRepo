/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

import com.tcs.ttg.installercreator.model.CopyFileCommand;
import com.tcs.ttg.installercreator.model.ExecuteScriptCommand;
import com.tcs.ttg.installercreator.model.ReplaceFileContentsCommand;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 *
 * @author Marimuthu912
 */
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type")
@JsonSubTypes({ 
  @Type(value = CopyFileCommand.class, name = "CopyFileCommand"), 
  @Type(value = ExecuteScriptCommand.class, name = "ExecuteScriptCommand"),
        @Type(value = ReplaceFileContentsCommand.class, name = "ReplaceFileContents")
})
public class PostInstallationCommand {

    /**
     * @return the stepName
     */
    public String getStepName() {
        return stepName;
    }

    /**
     * @param stepName the stepName to set
     */
    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    private String type;
    private String commandName;
    private String stepName;


    /**
     * @return the commandName
     */
    public String getCommandName() {
        return commandName;
    }

    /**
     * @param commandName the commandName to set
     */
    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }
    
}
