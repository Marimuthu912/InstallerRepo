/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.model;

import java.util.List;

/**
 *
 * @author Marimuthu912
 */
public class ExecuteScriptCommand extends PostInstallationCommand{
    
    private String scriptFilePath;
    private List<String> arguments;

    /**
     * @return the scriptFilePath
     */
    public String getScriptFilePath() {
        return scriptFilePath;
    }

    /**
     * @param scriptFilePath the scriptFilePath to set
     */
    public void setScriptFilePath(String scriptFilePath) {
        this.scriptFilePath = scriptFilePath;
    }

    /**
     * @return the arguments
     */
    public List<String> getArguments() {
        return arguments;
    }

    /**
     * @param arguments the arguments to set
     */
    public void setArguments(List<String> arguments) {
        this.arguments = arguments;
    }
}
