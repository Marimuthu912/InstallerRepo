/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ttg.installercreator.utils;

import com.tcs.ttg.installercreator.business.GlobalVars;
import com.tcs.ttg.installercreator.business.WizardPanel;
import com.tcs.ttg.installercreator.model.InstallationDetails;
import com.tcs.ttg.installercreator.model.StepDetails;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Marimuthu912
 */
public class WizardUtils {
public static void addStepPanelToViewPort(JFrame viewPort,int stepIndex,Map<Integer, StepDetails> mapOfStepIndexAndStepDetails,InstallationDetails installationDetails){
    
                if (viewPort.getContentPane().getComponents().length >= 2) {
                    viewPort.getContentPane().remove(1);
                }

                if (GlobalVars.mapOfStepIndexAndWizardPanel.containsKey(stepIndex)) {
                    viewPort.add(GlobalVars.mapOfStepIndexAndWizardPanel.get(stepIndex));
                } else {
                    WizardPanel wizardPanel = new WizardPanel();
                    wizardPanel.setViewPort(viewPort);
                    wizardPanel.setInstallationDetails(installationDetails);
                    wizardPanel.setCurrentStepIndex(stepIndex);
                    wizardPanel.setMapOfStepIndexAndStepDetails(mapOfStepIndexAndStepDetails);
                    JPanel nextStepPanel = wizardPanel.createWizardPanel();
                    viewPort.add(nextStepPanel);
                    GlobalVars.mapOfStepIndexAndWizardPanel.put(stepIndex, nextStepPanel);
                }
                viewPort.revalidate();
                viewPort.repaint();
}    
}
